<?php

$yourmail = 'youremail@email.com';



?>