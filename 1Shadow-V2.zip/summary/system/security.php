<?php

$securedby = 'youremail@email.com';



?>